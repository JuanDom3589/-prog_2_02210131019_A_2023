
package Taller1;

import java.util.Scanner;


public class Punto_4 {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Ingresa la palabra base: ");
    String wordBase = scan.nextLine();
    System.out.println("Ingresa 4 palabras más: ");
    String[] words = new String[4];
    for (int i = 0; i < 4; i++) {
      words[i] = scan.nextLine();
    }

   
    System.out.println("Verificación con ciclo for: ");
    for (String word : words) {
      for (int i = 0; i < word.length(); i++) {
        if (wordBase.contains(String.valueOf(word.charAt(i)))) {
          System.out.println("La palabra " + word + " encaja en la palabra base");
          break;
        }
      }
    }

   
    System.out.println("Verificación con ciclo while: ");
    int i = 0;
    while (i < words.length) {
      int j = 0;
      while (j < words[i].length()) {
        if (wordBase.contains(String.valueOf(words[i].charAt(j)))) {
          System.out.println("La palabra " + words[i] + " encaja en la palabra base");
          break;
        }
        j++;
      }
      i++;
    }

   
    System.out.println("Verificación con ciclo do-while: ");
    i = 0;
    do {
      int j = 0;
      do {
        if (wordBase.contains(String.valueOf(words[i].charAt(j)))) {
          System.out.println("La palabra " + words[i] + " encaja en la palabra base");
          break;
        }
        j++;
      } while (j < words[i].length());
      i++;
    } while (i < words.length);
  }
}
