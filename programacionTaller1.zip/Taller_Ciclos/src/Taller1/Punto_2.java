package Taller1;

import java.util.Scanner;


public class Punto_2 {
   public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.print("Ingrese el código estudiantil: ");
    String codigo = scan.nextLine();

  
    int numero = Integer.parseInt(codigo.substring(codigo.length() - 3));
    System.out.println("Número tomado: " + numero);

   
    System.out.println("Ciclo for:");
    forLoop(numero);

   
    System.out.println("Ciclo while:");
    whileLoop(numero);

  
    System.out.println("Ciclo do while:");
    doWhileLoop(numero);
  }

  public static void forLoop(int numero) {
    for (int i = 0; i <= numero; i++) {
      System.out.println(i);
    }
  }

  public static void whileLoop(int numero) {
    int i = 0;
    while (i <= numero) {
      System.out.println(i);
      i++;
    }
  }

  public static void doWhileLoop(int numero) {
    int i = 0;
    do {
      System.out.println(i);
      i++;
    } while (i <= numero);
  }
}
