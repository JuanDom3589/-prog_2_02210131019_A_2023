package Taller1;

import java.util.Random;

public class Punto_3 {

  public static void main(String[] args) {
    imprimirInventario();
  }
  
  public static void imprimirInventario() {
    
    Random aleatorio = new Random();
    
   
    int productos = 23;
    
    System.out.println("INVENTARIO:");
    
   
    System.out.println("\nCICLO FOR:");
    for (int i = 1; i <= productos; i++) {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + i + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
    }
    
  
    System.out.println("\nCICLO WHILE:");
    int j = 1;
    while (j <= productos) {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + j + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
      j++;
    }
    
   
    System.out.println("\nCICLO DO-WHILE:");
    int k = 1;
    do {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + k + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
      k++;
    } while (k <= productos);
  }
}
