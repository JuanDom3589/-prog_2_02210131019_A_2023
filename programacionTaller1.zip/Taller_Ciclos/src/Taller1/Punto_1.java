package Taller1;

import java.util.Scanner;

public class Punto_1 {

    
    
public static void reversoStringFor(String palabra){
    for (int i = palabra.length() - 1; i >= 0; i--) {
        System.out.print(palabra.charAt(i));
    }
    System.out.println();
}

public static void reversoStringWhile(String palabra){
    int i = palabra.length() - 1;
   while (i >= 0) {
      System.out.print(palabra.charAt(i));
      i--;
    }
    System.out.println();
}

public static void reversoStringDoWhile(String palabra){
    int i = palabra.length() - 1;
   do {
      System.out.print(palabra.charAt(i));
      i--;
    } while (i >= 0);
    System.out.println();
}

public static void main(String[] args) {
  
    Scanner sc = new Scanner(System.in);
        
    System.out.println("Escriba una palabra: ");
    String palabra = sc.nextLine();

    System.out.println("Reverso usando for: ");
    reversoStringFor(palabra);

    System.out.println("Reverso usando while: ");
    reversoStringWhile(palabra);

    System.out.println("Reverso usando do-while: ");
    reversoStringDoWhile(palabra);
    }
}
